@echo off
chcp 65001 >nul
title Chamdom Binance
cd /d "%~dp0"
if not exist bot_config.env (
  echo [설정 필요] bot_config.env 파일이 없습니다.
  echo 업비트 봇 폴더의 bot_config.env 를 이 폴더로 복사하고, 맨 아래에 바이낸스 키 3줄을 넣은 뒤 다시 실행하세요.
  pause
  exit /b
)
python -m pip install --quiet requests pyjwt
:loop
python binance_bot.py
if %errorlevel%==3 goto loop
echo.
echo [watchdog] binance engine stopped. restarting in 15 seconds. close this window to stop completely.
timeout /t 15
goto loop
