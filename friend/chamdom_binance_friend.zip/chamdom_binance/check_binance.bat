@echo off
chcp 65001 >nul
title Chamdom Binance Check
cd /d "%~dp0"
python -m pip install --quiet requests
python binance_check.py
pause
